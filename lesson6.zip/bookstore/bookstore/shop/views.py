from django.shortcuts import render
from .models import Author, Book, Customer

def authors_list(request):
    authors = Author.objects.all()
    return render(request, 'shop/authors_list.html', {'authors': authors})

def books_list(request):
    books = Book.objects.all()
    return render(request, 'shop/books_list.html', {'books': books})

def customers_list(request):
    customers = Customer.objects.all()
    return render(request, 'shop/customers_list.html', {'customers': customers})
