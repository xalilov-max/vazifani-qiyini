from django.shortcuts import render
from .models import Article

def home(request):
    articles = Article.objects.all()
    return render(request, 'news/home.html', {'articles': articles})

def home_view(request):
    return render(request, 'home.html') 
